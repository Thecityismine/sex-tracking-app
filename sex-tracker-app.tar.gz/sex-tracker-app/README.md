# Tracker App

A minimal, dark-themed personal tracking web app built with Next.js, Tailwind CSS, and Supabase.

## Features

- ✅ Monthly calendar view with activity tracking
- ✅ Tap days to toggle entries on/off
- ✅ Red dots indicate logged days
- ✅ Monthly and weekly statistics
- ✅ Days since last activity
- ✅ Longest gap tracking
- ✅ Year summary progress bars
- ✅ Optional notes per entry
- ✅ Multi-device sync via Supabase
- ✅ Dark theme only
- ✅ Mobile responsive

## Tech Stack

- **Frontend**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS
- **Backend**: Supabase (Postgres)
- **Hosting**: Vercel
- **Date Library**: date-fns

## Setup Instructions

### 1. Clone or Download

```bash
cd sex-tracker-app
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Set Up Supabase

1. Go to [supabase.com](https://supabase.com) and create a new project
2. Once the project is created, go to the SQL Editor
3. Copy the contents of `supabase-schema.sql` and run it in the SQL Editor
4. Go to Project Settings > API to get your credentials:
   - Project URL
   - Anon/Public Key

### 4. Configure Environment Variables

Create a `.env.local` file in the root directory:

```bash
cp .env.local.example .env.local
```

Edit `.env.local` and add your Supabase credentials:

```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 5. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deployment to Vercel

### Option 1: Deploy via Vercel CLI

1. Install Vercel CLI:
```bash
npm i -g vercel
```

2. Deploy:
```bash
vercel
```

3. Add environment variables in Vercel dashboard:
   - Go to your project settings
   - Add `NEXT_PUBLIC_SUPABASE_URL`
   - Add `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### Option 2: Deploy via Vercel Dashboard

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Add environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
6. Click "Deploy"

## Usage

### Logging Activity

- Click any day in the calendar to log activity
- A red dot appears on logged days
- Click again to open the note editor

### Adding Notes

- Click a logged day to open the note editor
- Type your note (optional)
- Click "Save Note"

### Viewing All Notes

- Click "View All Notes" button at the bottom
- See all entries with notes in chronological order

### Navigation

- Use arrow buttons to navigate between months
- Year summary arrows to view different years
- Statistics update automatically

## File Structure

```
sex-tracker-app/
├── app/
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── CalendarGrid.tsx
│   ├── StatCards.tsx
│   ├── YearSummary.tsx
│   └── NotesPanel.tsx
├── lib/
│   ├── supabase.ts
│   └── calculations.ts
├── supabase-schema.sql
├── package.json
├── tsconfig.json
├── tailwind.config.js
├── postcss.config.js
└── next.config.js
```

## Color Theme

- Background: `#0b0b0f`
- Cards: `#15151c`
- Text: `#eaeaf0`
- Muted: `#9a9aa3`
- Accent Red: `#ff3b3b`
- Accent Blue: `#3b82f6`

## Database Schema

```sql
entries
├── id (UUID, primary key)
├── date (DATE, unique)
├── created_at (TIMESTAMP)
└── note (TEXT, nullable)
```

## Future Enhancements

Potential features to add:

- PWA support for mobile installation
- Face ID / biometric lock
- Export data to CSV
- Custom app icon and name
- Data backup/restore
- Dark/light theme toggle
- Streak tracking
- Custom statistics

## License

MIT
