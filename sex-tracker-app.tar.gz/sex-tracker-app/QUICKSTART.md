# Quick Start Guide

Get your tracker app running in 5 minutes.

## 1. Install Dependencies

```bash
npm install
```

## 2. Set Up Supabase (2 minutes)

1. Go to [supabase.com](https://supabase.com) → Create account → New Project
2. Go to SQL Editor → Paste contents of `supabase-schema.sql` → Run
3. Go to Project Settings → API → Copy your URL and anon key

## 3. Configure Environment

```bash
# Create .env.local file
cp .env.local.example .env.local

# Edit .env.local and paste your Supabase credentials
```

## 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## 5. Test It Out

- Click any day to log activity
- Click again to add a note
- See stats update in real-time

---

## Deploy to Production

See [DEPLOYMENT.md](./DEPLOYMENT.md) for full instructions.

**TL;DR:**
```bash
# Push to GitHub
git init
git add .
git commit -m "Initial commit"
git push

# Deploy on Vercel
# 1. Go to vercel.com
# 2. Import your GitHub repo
# 3. Add environment variables
# 4. Deploy
```

---

## What You Get

✅ Monthly calendar with activity dots  
✅ Weekly & monthly statistics  
✅ Days since last activity  
✅ Longest gap tracking  
✅ Year progress summary  
✅ Optional notes per entry  
✅ Multi-device sync  
✅ Dark theme  

---

## Need Help?

Check [README.md](./README.md) for full documentation.
