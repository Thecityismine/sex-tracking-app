# Project Structure

Complete overview of all files and their purposes.

## Root Files

```
.
├── package.json              # Dependencies and scripts
├── tsconfig.json             # TypeScript configuration
├── next.config.js            # Next.js configuration
├── tailwind.config.js        # Tailwind CSS theme
├── postcss.config.js         # PostCSS configuration
├── .gitignore                # Git ignore rules
├── .env.local.example        # Environment variables template
├── supabase-schema.sql       # Database schema
├── README.md                 # Main documentation
├── DEPLOYMENT.md             # Deployment instructions
└── QUICKSTART.md             # Quick start guide
```

## App Directory (`/app`)

```
app/
├── layout.tsx                # Root layout with metadata
├── page.tsx                  # Main dashboard page
└── globals.css               # Global styles with Tailwind
```

### `layout.tsx`
- Sets up the HTML structure
- Imports global styles
- Defines metadata (title, description)
- Applies Inter font

### `page.tsx`
- Main dashboard logic
- State management for entries
- Handles date selection
- Manages Supabase operations
- Orchestrates all components

### `globals.css`
- Tailwind directives
- Base styles
- Background color
- Text color

## Components Directory (`/components`)

```
components/
├── CalendarGrid.tsx          # Monthly calendar view
├── StatCards.tsx             # Statistics cards
├── YearSummary.tsx           # Year progress bars
└── NotesPanel.tsx            # Note editor and viewer
```

### `CalendarGrid.tsx`
- Renders monthly calendar grid
- Shows red dots for logged days
- Handles day clicks
- Month navigation arrows
- Day of week headers

### `StatCards.tsx`
- Four statistics cards:
  - Total this month
  - Total this week
  - Days since last
  - Longest gap
- Auto-calculates from entries
- Updates in real-time

### `YearSummary.tsx`
- Red progress bar (logged days)
- Blue progress bar (total days)
- Year navigation
- Percentage calculation

### `NotesPanel.tsx`
- Note editor modal
- View all notes list
- Save/edit functionality
- Date formatting

## Library Directory (`/lib`)

```
lib/
├── supabase.ts               # Supabase client
└── calculations.ts           # Statistics calculations
```

### `supabase.ts`
- Creates Supabase client
- Exports Entry type
- Configures connection

### `calculations.ts`
- `getTotalThisMonth()` - Counts entries in current month
- `getTotalThisWeek()` - Counts entries in current week (Mon-Sun)
- `getDaysSinceLast()` - Calculates days since last entry
- `getLongestGap()` - Finds longest gap between consecutive entries
- `getYearSummary()` - Calculates yearly progress

## Database Schema (`supabase-schema.sql`)

```sql
CREATE TABLE entries (
  id UUID PRIMARY KEY,
  date DATE UNIQUE NOT NULL,
  created_at TIMESTAMP,
  note TEXT
);
```

**Fields:**
- `id` - Unique identifier
- `date` - Activity date (unique constraint)
- `created_at` - Timestamp when created
- `note` - Optional text note

**Indexes:**
- Primary key on `id`
- Unique index on `date`
- Additional index for faster queries

**Security:**
- Row Level Security enabled
- "Allow all operations" policy (single-user)

## Key Features by File

### Activity Logging
- **Primary:** `CalendarGrid.tsx` + `page.tsx`
- User clicks day → Creates entry → Shows red dot

### Statistics
- **Primary:** `StatCards.tsx` + `calculations.ts`
- Reads all entries → Calculates stats → Displays cards

### Notes
- **Primary:** `NotesPanel.tsx` + `page.tsx`
- Click logged day → Opens editor → Saves to Supabase

### Year Progress
- **Primary:** `YearSummary.tsx` + `calculations.ts`
- Filters entries by year → Calculates progress → Shows bars

### Data Sync
- **Primary:** `supabase.ts` + `page.tsx`
- All CRUD operations go through Supabase
- Real-time sync across devices

## Data Flow

```
User Action (CalendarGrid)
    ↓
Event Handler (page.tsx)
    ↓
Supabase Client (supabase.ts)
    ↓
Postgres Database
    ↓
Updated State (page.tsx)
    ↓
Re-render Components
```

## Component Hierarchy

```
page.tsx (Dashboard)
├── CalendarGrid
│   └── Day cells with click handlers
├── StatCards
│   └── Four stat cards
├── YearSummary
│   ├── Red progress bar
│   └── Blue progress bar
└── NotesPanel (Modal)
    ├── Note editor
    └── All notes list
```

## State Management

All state lives in `page.tsx`:
- `entries` - Array of all entries from Supabase
- `currentDate` - Currently viewed month
- `selectedYear` - Year for summary
- `selectedDate` - Date for note editor
- `selectedEntry` - Entry being edited
- `loading` - Loading state

## Styling System

- **Framework:** Tailwind CSS
- **Theme:** Custom dark theme
- **Colors:** Defined in `tailwind.config.js`
- **Responsive:** Mobile-first design
- **Rounded:** All corners rounded (cards, buttons)

## API Routes

None! All data operations go directly from client to Supabase.

## Environment Variables

Required in `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL       # Your Supabase project URL
NEXT_PUBLIC_SUPABASE_ANON_KEY  # Your Supabase anon/public key
```

## Build & Deploy

- **Dev:** `npm run dev`
- **Build:** `npm run build`
- **Start:** `npm start`
- **Deploy:** Push to GitHub → Auto-deploy on Vercel

## Dependencies

**Core:**
- `next` - Framework
- `react` - UI library
- `@supabase/supabase-js` - Database client
- `date-fns` - Date utilities

**Dev:**
- `typescript` - Type safety
- `tailwindcss` - Styling
- `autoprefixer` - CSS compatibility
- `postcss` - CSS processing

## File Sizes (approx.)

- `CalendarGrid.tsx` - ~100 lines
- `StatCards.tsx` - ~50 lines
- `YearSummary.tsx` - ~70 lines
- `NotesPanel.tsx` - ~120 lines
- `page.tsx` - ~110 lines
- `calculations.ts` - ~80 lines
- `supabase.ts` - ~10 lines

Total: ~500 lines of actual code (excluding config)

## Modification Guide

**Add new statistic:**
1. Add function to `calculations.ts`
2. Add card to `StatCards.tsx`

**Change theme:**
1. Edit colors in `tailwind.config.js`
2. Update any hardcoded colors

**Add authentication:**
1. Enable Supabase Auth
2. Update RLS policies
3. Add auth UI to `page.tsx`

**Add new feature:**
1. Create component in `/components`
2. Import in `page.tsx`
3. Update state if needed

## Testing Locally

```bash
# Install dependencies
npm install

# Set up .env.local with Supabase credentials

# Run dev server
npm run dev

# Test in browser
# - Click days
# - Add notes
# - Check stats
# - Navigate months/years
```

## Common Tasks

**Reset database:**
```sql
DELETE FROM entries;
```

**Export data:**
```sql
SELECT * FROM entries ORDER BY date;
```

**Check row count:**
```sql
SELECT COUNT(*) FROM entries;
```

**Find gaps:**
Look at `getLongestGap()` in `calculations.ts`

---

That's the complete project structure! Every file has a clear, single purpose.
