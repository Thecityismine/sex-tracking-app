# Deployment Guide

## Step-by-Step Deployment to Vercel + Supabase

### Prerequisites

- A GitHub account
- A Vercel account (free tier is fine)
- A Supabase account (free tier is fine)

---

## Part 1: Set Up Supabase Backend

### 1. Create Supabase Project

1. Go to [https://supabase.com](https://supabase.com)
2. Click "Start your project"
3. Sign in with GitHub
4. Click "New Project"
5. Fill in:
   - Project name: `tracker-app` (or any name you want)
   - Database password: (generate a strong one)
   - Region: Choose closest to you
6. Click "Create new project"
7. Wait 2-3 minutes for setup

### 2. Create Database Table

1. In your Supabase project, go to "SQL Editor" in the left sidebar
2. Click "New Query"
3. Copy and paste the entire contents of `supabase-schema.sql`
4. Click "Run" or press `Cmd/Ctrl + Enter`
5. You should see "Success. No rows returned"

### 3. Get API Credentials

1. Go to "Project Settings" (gear icon in left sidebar)
2. Click "API" in the sidebar
3. Copy these two values:
   - **Project URL** (looks like `https://xxxxx.supabase.co`)
   - **anon public** key (under "Project API keys")
4. Save these somewhere - you'll need them in a moment

---

## Part 2: Deploy to Vercel

### Method A: Deploy via GitHub (Recommended)

#### Step 1: Push Code to GitHub

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit"

# Create a new repository on GitHub, then:
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
git branch -M main
git push -u origin main
```

#### Step 2: Connect to Vercel

1. Go to [https://vercel.com](https://vercel.com)
2. Sign in with GitHub
3. Click "Add New..." → "Project"
4. Import your GitHub repository
5. Vercel will auto-detect it's a Next.js project

#### Step 3: Configure Environment Variables

1. Before deploying, expand "Environment Variables"
2. Add two variables:

   **Variable 1:**
   - Name: `NEXT_PUBLIC_SUPABASE_URL`
   - Value: (paste your Supabase Project URL)

   **Variable 2:**
   - Name: `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - Value: (paste your Supabase anon key)

3. Click "Deploy"

#### Step 4: Wait for Deployment

- Deployment takes 1-2 minutes
- You'll get a URL like `https://your-app.vercel.app`
- Click "Visit" to see your app live!

---

### Method B: Deploy via Vercel CLI

```bash
# Install Vercel CLI globally
npm install -g vercel

# Login
vercel login

# Deploy
vercel

# Follow prompts:
# - Link to existing project? No
# - What's your project's name? tracker-app
# - In which directory is your code? ./
# - Want to override settings? No

# Add environment variables
vercel env add NEXT_PUBLIC_SUPABASE_URL
# Paste your Supabase URL when prompted

vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
# Paste your Supabase anon key when prompted

# Deploy to production
vercel --prod
```

---

## Part 3: Test Your Deployment

1. Visit your Vercel URL
2. Click on any day in the calendar
3. You should see a red dot appear
4. Click the day again to add a note
5. Refresh the page - your data should persist
6. Open the app on another device - data should sync

---

## Troubleshooting

### Issue: "Error fetching entries"

**Solution:** Check your environment variables
1. Go to Vercel Dashboard → Your Project → Settings → Environment Variables
2. Make sure both variables are set correctly
3. Redeploy if you made changes

### Issue: Calendar loads but entries don't save

**Solution:** Check Supabase RLS policies
1. Go to Supabase Dashboard → Authentication → Policies
2. Make sure the "Allow all operations" policy exists on the `entries` table
3. If not, re-run the SQL schema

### Issue: Build fails on Vercel

**Solution:** Check your code for TypeScript errors
```bash
# Run locally to see errors
npm run build
```

---

## Post-Deployment Checklist

✅ App loads at Vercel URL  
✅ Can click days to log entries  
✅ Red dots appear on logged days  
✅ Statistics update correctly  
✅ Can add and save notes  
✅ Data persists after refresh  
✅ Works on mobile device  

---

## Optional: Custom Domain

1. Go to Vercel Dashboard → Your Project → Settings → Domains
2. Add your custom domain
3. Follow DNS configuration instructions
4. Wait for DNS propagation (up to 24 hours)

---

## Security Notes

### Current Setup (Single User)

The app is currently configured with an "Allow all operations" policy in Supabase. This is fine for:
- Personal use
- Single user
- No sensitive data

### For Multi-User or Production

If you want to add authentication later:

1. Enable Supabase Auth
2. Update RLS policies in Supabase
3. Add authentication to the Next.js app
4. Restrict operations to authenticated users

---

## Updating Your App

### After making code changes:

**Via GitHub:**
```bash
git add .
git commit -m "Your changes"
git push
```
Vercel will auto-deploy the changes.

**Via CLI:**
```bash
vercel --prod
```

---

## Need Help?

Common resources:
- [Next.js Docs](https://nextjs.org/docs)
- [Supabase Docs](https://supabase.com/docs)
- [Vercel Docs](https://vercel.com/docs)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)

---

## Congratulations! 🎉

Your app is now live and accessible from anywhere. You can:
- Access it from any device
- Data syncs automatically
- Add it to your home screen (PWA)
- Share the URL (if you want)

Enjoy tracking! 📊
